from django.contrib import admin
from .models import Diary

admin.site.register(Diary)