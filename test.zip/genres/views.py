import requests
from django.shortcuts import render

def genre_list(request):
    # TMDb API로 장르 목록을 가져옵니다.
    url = "https://api.themoviedb.org/3/genre/movie/list?language=ko"
    headers = {
        "accept": "application/json",
        "Authorization": "Bearer YOUR_API_KEY"  # 실제 API 키로 교체
    }

    response = requests.get(url, headers=headers)
    genres = response.json().get('genres', [])  # 'genres' 키에서 장르 목록을 추출
    
    return render(request, 'genres/category.html', {'genres': genres})

def genre_detail(request, genre_id):
    # TMDb API로 해당 장르의 영화를 가져옵니다.
    url = f"https://api.themoviedb.org/3/discover/movie?with_genres={genre_id}&language=ko"
    headers = {
        "accept": "application/json",
        "Authorization": "Bearer YOUR_API_KEY"  # 실제 API 키로 교체
    }

    response = requests.get(url, headers=headers)
    movies = response.json().get('results', [])  # 영화 목록 추출
    genre_name = response.json().get('genres')[0]['name']  # 장르 이름 추출

    return render(request, 'genres/genre_detail.html', {'movies': movies, 'genre_name': genre_name})
