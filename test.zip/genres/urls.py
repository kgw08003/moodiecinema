from .urls import path
from . import views

urlpatterns = [
    path('', views.genre_list, name='genre_list'),  # 장르 목록 페이지
    path('<int:genre_id>/', views.genre_detail, name='genre_detail'),  # 장르별 영화 페이지
]